<div class=" ml-lg-auto col-lg-10 py-3 text-left d-lg-block d-flex">
    @include('partials.menuBtn')
    @include('partials.searchBar')
</div>