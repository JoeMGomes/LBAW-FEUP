<main id="main" class="ml-lg-auto col-lg-10 align-right ">
    <div class=" ml-lg-auto w-100 pb-0">
        <div class="ml-1 d-flex align-items-center justify-content-between mb-3">
            <div class="col-lg-5">
                <label for="sort" class="sorter-label "> Sorted by</label>
                <select id="sort" class=" custom-select col-5">
                    <option>Most answers</option>
                    <option>Most recent</option>
                </select>
            </div>
            <span class="pr-4 mr-4 text-nowrap"> <?php echo e(count($results)); ?> results found </span>
        </div>

        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('partials.searchResult', $result, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
</main><?php /**PATH /home/joe/Documents/FEUP/lbaw2075/A8/resources/views/partials/searchMain.blade.php ENDPATH**/ ?>