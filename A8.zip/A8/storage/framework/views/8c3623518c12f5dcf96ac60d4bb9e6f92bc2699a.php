<?php $__env->startSection('body'); ?>
<body class="bg-mydark text-center">
  <div class="h-100 d-flex justify-content-center align-items-center">
    <form method="POST" action="<?php echo e(route('signup')); ?>"
      class="form-container p-3 rounded col-lg-4 col-md-6 col-10 bg-white my-auto">
      <?php echo e(csrf_field()); ?>

      <a href="mainPage.php">
        <img src="<?php echo e(asset('img/logo2.png')); ?>" class="register-logo my-3 " width="100px" alt="Company Logo">
      </a>
      <h3 class="mb-3 text-mydarkgreen">Sign up</h3>
      <div class="form-group">
        <label class="float-left" for="inputEmail">e-mail</label>
        <input type="email" name="email" id="inputEmail" class="form-control" value="<?php echo e(old('email')); ?>" required autofocus>
        <?php if($errors->has('email')): ?>
        <span class="error">
          <?php echo e($errors->first('email')); ?>

        </span>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label class="float-left" for="inputUsername">name</label>
        <input type="text" name="name" id="inputUsername" class="form-control" value="<?php echo e(old('name')); ?>" required>
        <?php if($errors->has('name')): ?>
        <span class="error">
          <?php echo e($errors->first('name')); ?>

        </span>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label class="float-left" for="password">password</label>
        <input type="password" name="password" id="password" class="form-control" required>
        <?php if($errors->has('password')): ?>
        <span class="error">
          <?php echo e($errors->first('password')); ?>

        </span>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label class="float-left" for="password-confirm">confirm password</label>
        <input type="password" id="password-confirm" name="password_confirmation" class="form-control" required>
      </div>
      <button class="mb-4 btn btn-dark" type="submit" >Sign up</button>
      <div>
        <small class="justify-content-center">
          Already have an account?
          <a class="text-mydarkblue text-darkblueh" href="<?php echo e(route('login')); ?>">Log in</a>
        </small>
      </div>
    </form>
  </div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joe/Documents/FEUP/lbaw2075/A8/resources/views/auth/register.blade.php ENDPATH**/ ?>