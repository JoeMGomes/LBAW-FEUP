<a class="btn btn-primary btn-customized text-nowrap bg-dark open-menu d-lg-none" href="#" role="button" alt="Menu">
    <i class="fa fa-align-left" alt="Menu"></i> <span class="d-none d-md-inline">Menu</span>
</a>