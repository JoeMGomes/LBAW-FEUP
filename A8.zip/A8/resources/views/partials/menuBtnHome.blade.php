<div class="d-lg-none" style="position:fixed; z-index: 900; top: 1.5rem; left: 1.5rem">
    <a class="btn btn-primary btn-customized text-nowrap bg-dark open-menu d-lg-none" href="#" role="button"
            alt="Menu">
        <i class="fa fa-align-left" alt="Menu"></i> <span class="d-none d-md-inline">Menu</span>
    </a>
</div>