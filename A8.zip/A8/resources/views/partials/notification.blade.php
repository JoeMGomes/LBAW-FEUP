<div class=" d-flex justify-content-start notifications mb-3 px-2">
    <i class="fa fa-circle pt-3 pr-2" style="color: #7a86ef"></i>
    <span>3 users answered your question: "<strong>HOW DO I WASH MY YELLOW JACKET?</strong>"
        <div class="text-left pl-4">
            5m ago
        </div>
    </span>
</div>