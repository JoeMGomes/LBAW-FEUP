<div class="d-flex pl-4 pr-4 w-100">
    <div class="flex-column d-none d-md-flex ">
        <img src="<?php echo e(asset('img/'.$result['qphoto'])); ?>" class="rounded-img " alt="User Photo" />
        <small class="text-center mt-2"><?php echo e($result['qname']); ?></small>
    </div>
    <div class="ml-4 w-100">
        <a class="text-black" href="#NOT_IMPLEMENTED">
            <h3 class="mb-3"> <small>(<u>Edited</u>)</small> <?php echo e($result['title']); ?></h3>
        </a>
        <p class="text-justified ">
            <?php echo e($result['text_body']); ?>

        </p>
        <div class="d-flex row align-items-end justify-content-end">
            <div class="text-right text-nowrap">
                <small> Asked on <?php echo e(date('M d, Y @ H:i ', strtotime($result['qdate']))); ?> </small>
                <?php echo $__env->make('partials.report', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/joe/Documents/FEUP/lbaw2075/A8/resources/views/partials/searchQuestion.blade.php ENDPATH**/ ?>