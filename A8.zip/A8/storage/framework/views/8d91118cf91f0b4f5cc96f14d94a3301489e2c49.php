<?php $__env->startSection('body'); ?>

<body class="bg-mydark text-center">
    <div class="h-100 d-flex justify-content-center align-items-center">
        <form method="POST" action="<?php echo e(route('login')); ?>"
            class="form-container p-3 rounded bg-white my-auto col-lg-4 col-md-6 col-10">
            <?php echo e(csrf_field()); ?>

            <a href="mainPage.php">
                <img src="<?php echo e(asset('img/logo2.png')); ?>" class="register-logo my-3 " tabindex="1" width="100px"
                    alt="Company Logo">
            </a>
            <h3 class="mb-3 text-mydarkblue">Log in</h3>
            <div class="form-group">
                <label class="float-left" for="inputEmail">e-mail</label>
                <input type="email" name="email" id="inputEmail" class="form-control" value="<?php echo e(old('email')); ?>"
                    required autofocus>
                <?php if($errors->has('email')): ?>
                <span class="error">
                    <?php echo e($errors->first('email')); ?>

                </span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label class="float-left" for="password">password</label>
                <input type="password" name="password" id="password" class="form-control" value="<?php echo e(old('passowrd')); ?>" required="">
                <?php if($errors->has('password')): ?>
                <span class="error">
                    <?php echo e($errors->first('password')); ?>

                </span>
                <?php endif; ?>
            </div>
        <button class="mb-4 btn btn-dark" type="submit" href="<?php echo e(route('login')); ?>">Log in</button>
            <div>
                <small class="justify-content-center">
                    Don't have an account?
                    <a class="text-mydarkgreen text-darkgreenh" href="<?php echo e(route('signup')); ?>">Sign up</a>
                </small>
            </div>
        </form>
    </div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joe/Documents/FEUP/lbaw2075/A8/resources/views/auth/login.blade.php ENDPATH**/ ?>