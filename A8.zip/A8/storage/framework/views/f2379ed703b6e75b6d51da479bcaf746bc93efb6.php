<div class=" ml-lg-auto col-lg-10 py-3 text-left d-lg-block d-flex">
    <?php echo $__env->make('partials.menuBtn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.searchBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH /home/joe/Documents/FEUP/lbaw2075/A8/resources/views/partials/navBarTop.blade.php ENDPATH**/ ?>