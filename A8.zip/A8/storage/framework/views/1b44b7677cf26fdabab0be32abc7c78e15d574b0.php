<div class="border d-flex flex-column bg-light w-90 align-items-center py-3 mb-3">
    <?php echo $__env->make('partials.searchQuestion', $result, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(isset($result['answer'])): ?>
        <?php echo $__env->make('partials.searchBestAnswer', $result, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH /home/joe/Documents/FEUP/lbaw2075/A8/resources/views/partials/searchResult.blade.php ENDPATH**/ ?>