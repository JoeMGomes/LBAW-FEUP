<div class="d-flex align-items-center w-100 ">
    <div class="border w-100 d-flex flex-column mx-4 px-3 py-3 bg-white">
        <span class="text-danger text-nowrap"> <i class="fa fa-heart"></i> Best Answer!</span>
        <p class="text-justify">
            <?php echo e($result['answer']); ?>

        </p>
        <div class="d-flex flex-wrap justify-content-between align-items-center">
            <div class="flex-column align-items-center mr-3">
                <span class="text-nowrap">
                    <img src="<?php echo e(asset('img/'.$result['aphoto'])); ?>" class="reply-img mr-2" alt="User Photo" />
                    &#8212 <?php echo e($result['aname']); ?>

                </span>
                <small class="small"> <?php echo e($result['score']); ?> points | Member since <?php echo e(date('M Y', strtotime($result['membership_date']))); ?></small>
            </div>
            <div>
                <small> Replied on <?php echo e(date('M d, Y @ H:i',strtotime($result['adate']))); ?> </small>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/joe/Documents/FEUP/lbaw2075/A8/resources/views/partials/searchBestAnswer.blade.php ENDPATH**/ ?>