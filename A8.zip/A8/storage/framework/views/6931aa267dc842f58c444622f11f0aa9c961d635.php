<?php $__env->startSection('main'); ?>
        <?php echo $__env->make('partials.navBarTop', $search, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('partials.searchMain', $results, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joe/Documents/FEUP/lbaw2075/A8/resources/views/pages/search.blade.php ENDPATH**/ ?>